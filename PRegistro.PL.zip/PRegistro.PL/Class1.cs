﻿using System;

namespace PStudent.BL
{
    public class Class1
    {

    }
}